#!/bin/bash
# Di chuyển vào đúng thư mục làm việc của Codespace
cd /workspaces/*
# Tắt tiến trình m.py cũ nếu có để tránh chạy đè
pkill -f m.py
# Chạy ngầm m.py độc lập hoàn toàn với hệ thống
nohup python3 m.py > bot_output.log 2>&1 &